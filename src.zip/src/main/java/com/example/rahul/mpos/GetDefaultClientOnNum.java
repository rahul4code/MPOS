package com.example.rahul.mpos;

import android.content.Context;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class GetDefaultClientOnNum
{
    Context a;
    public void GetDefaultCustomer(Context x ,String clientURL, final EditText txtname, final EditText txtnumber, final ArrayList<String> DefaultClientData) {
        RequestQueue requestQueue = Volley.newRequestQueue(x);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, clientURL,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            JSONArray jsonArray = jsonObject.getJSONArray("DefaultClient");
                            String name = null;
                            String number = null;
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                name = jsonObject1.getString("Name");
                                DefaultClientData.add(name);
                                number = jsonObject1.getString("ContactNo");
                                DefaultClientData.add(number);

                            } txtname.setText(name);
                            txtnumber.setText(number);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        int socketTimeout = 30000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(policy);
        requestQueue.add(stringRequest);

    }
}
