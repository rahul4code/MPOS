package com.example.rahul.mpos;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

public class WelcomeSplash extends AppCompatActivity
{

    RelativeLayout iconcontainer,poslable;
    public static int SPLASH_TIME_OUT=3000;
    ProgressBar mprogress;

    Handler handler=new Handler();
    Runnable runable=new Runnable()
    {
        @Override
        public void run() {
            poslable.setVisibility(View.VISIBLE);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_welcome_splash);

        new Thread(new Runnable() {
            public void run() {
                doWork();
                finish();
            }
        }).start();

        iconcontainer=(RelativeLayout)findViewById(R.id.iconcontainer);
        poslable=(RelativeLayout)findViewById(R.id.poslabel);
        mprogress=(ProgressBar)findViewById(R.id.mprogress);

        handler.postDelayed(runable,2000);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run()
            {
                Intent HomeIntent=new Intent(WelcomeSplash.this,MainActivity.class);
                startActivity(HomeIntent);
                finish();
            }
        },SPLASH_TIME_OUT);

    }
    private void doWork() {
        for (int progress=10; progress<300; progress+=15) {
            try {
                Thread.sleep(500);
                mprogress.setProgress(progress);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
