package com.example.rahul.mpos;

import android.content.Context;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SearchClient
{
    Context a;
    public void GetSearchCustomer(Context x, String clientURL, final TextView tname, final TextView taddress, final TextView tcnumber, final TextView tpnumber,
                                  final TextView temail, final TextView tgumber, final ArrayList<String> ClientData, String enternumber)
    {
            String c = "";
            c = clientURL + "?clientMobileNo=" + enternumber;

        RequestQueue requestQueue = Volley.newRequestQueue(x);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, c,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response)
                    {
                        if(response.trim()=="NoRecord")
                        {
                            tcnumber.setText("No Record Found");
                        }
                        else
                        {
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                JSONArray jsonArray = jsonObject.getJSONArray("SearchClient");
                                String name = null;
                                String address= null;
                                String number = null;
                                String pan=null;
                                String email=null;
                                String gst=null;

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    name = jsonObject1.getString("Name");
                                    ClientData.add(name);
                                    number = jsonObject1.getString("ContactNo");
                                    ClientData.add(number);
                                    address = jsonObject1.getString("Address");
                                    ClientData.add(address);
                                    pan = jsonObject1.getString("PanNo");
                                    ClientData.add(pan);
                                    email = jsonObject1.getString("EmailId");
                                    ClientData.add(email);
                                    gst = jsonObject1.getString("GSTNo");
                                    ClientData.add(gst);
                                }
                                tname.setText("Name: "+name);
                                taddress.setText("Address: "+address);
                                tcnumber.setText("Contact No: "+number);
                                tpnumber.setText("Pan No: "+pan);
                                temail.setText("Email: "+email);
                                tgumber.setText("GST No: "+gst);
                            }
                            catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        int socketTimeout = 30000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(policy);
        requestQueue.add(stringRequest);
    }

}
