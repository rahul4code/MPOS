package com.example.rahul.mpos;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

    private Context context;
    private List<Category_List> list;


    public CategoryAdapter(Context context, List<Category_List> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v = LayoutInflater.from(context).inflate(R.layout.category_layout, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Category_List movie = list.get(position);

        holder.btn_category.setText(movie.getTitle());
        holder.btn_id.setText(movie.getId());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener  {
        public Button btn_category;
        public TextView btn_id;


        public ViewHolder(View itemView)
        {
            super(itemView);
            btn_category = itemView.findViewById(R.id.btn_category);
            btn_id = itemView.findViewById(R.id.btn_id);
            btn_category.setOnClickListener(this);
        }

        @Override
        public void onClick(View v)
        {
            String s = (String) btn_id.getText();
            MainActivity.getInstance().getproductData(s);
        }
    }
}