package com.example.rahul.mpos;

public class ClientDetailList
{
    public String name;
    public String number;
    public String address;
    public String pan;
    public  String gst;
    public String email;

    public String getName() {
        return name;
    }

    public String getNumber() {
        return number;
    }

    public String getAddress() {
        return address;
    }

    public String getPan() {
        return pan;
    }

    public String getGst() {
        return gst;
    }

    public String getEmail() {
        return email;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public void setGst(String gst) {
        this.gst = gst;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public ClientDetailList()
    {

    }
}
