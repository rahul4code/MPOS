package com.example.rahul.mpos;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;



public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    //Sql Save Data
    SQLiteDatabase db;
    DBManager cm;
    Cursor c;

    //Cart Data
    private RecyclerView mList3;
    private LinearLayoutManager linearLayoutManager3;
    private DividerItemDecoration dividerItemDecoration3;
    public List<CartList> movieList3;
    private RecyclerView.Adapter adapter3;

    //product data
    private RecyclerView mList2;
    private LinearLayoutManager linearLayoutManager2;
    private DividerItemDecoration dividerItemDecoration2;
    public List<Product_List> movieList2;
    private RecyclerView.Adapter adaptera2;

    //category data
    private RecyclerView mList;
    private LinearLayoutManager linearLayoutManager;
    private DividerItemDecoration dividerItemDecoration;
    private List<Category_List> movieList;
    private RecyclerView.Adapter adaptera;


    private String url = "http://192.168.1.50/Mpostest/GstBilling.asmx/GetCategory";
    private String url2 = "http://192.168.1.50/Mpostest/GstBilling.asmx/GetProductByCategoryId";

    //Get Default Client Data
    ArrayList<String> DefaultClientData = new ArrayList<>();
    String clientURL = "http://192.168.1.50/Mpostest/GstBilling.asmx/GetDefaultClient";

    private static MainActivity instance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        LinearLayout addcustomer = (LinearLayout) findViewById(R.id.addcustomer);
        LinearLayout searchcustomer = (LinearLayout) findViewById(R.id.searchcustomer);
        instance = this;

        //Default Client Show
        final EditText txtname = (EditText) findViewById(R.id.txtname);
        final EditText txtnumber = (EditText) findViewById(R.id.txtnumber);

        GetDefaultClientOnNum obj = new GetDefaultClientOnNum();
        Context x = getApplicationContext();
        obj.GetDefaultCustomer(x, clientURL, txtname, txtnumber, DefaultClientData);

        //Random Cart Id Generate
        randomAlphaNumeric random = new randomAlphaNumeric();
        String s = random.CallrandomAlphaNumeric(10);
        Toast.makeText(x, "Cart Id Generated Save to sqlite"+s, Toast.LENGTH_SHORT).show();

        //Bind Client Data
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.add_customer);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(true);
        Context z = getApplicationContext();

        ArrayList<String> CountryName = new ArrayList<String>();
        final ArrayList<String> StateName = new ArrayList<String>();
        final ArrayList<String> CityName = new ArrayList<String>();

        final String StateURL = "http://192.168.1.50//Mpostest/GstBilling.asmx/LoadState";
        final String URL = "http://192.168.1.50/Mpostest/GstBilling.asmx/LoadCountry";
        final String CityUrl = "http://192.168.1.50//Mpostest/GstBilling.asmx/LoadCity";
        final String DefaultClientUrl = "http://192.168.1.50/Mpostest/GstBilling.asmx/GetDefaultClient";

        final Spinner spinner = (Spinner) dialog.findViewById(R.id.countryspinner);
        final Spinner StateSpinner = (Spinner) dialog.findViewById(R.id.StateSpinner);
        final Spinner CitySpinner = (Spinner) dialog.findViewById(R.id.CitySpinner);
        final EditText emailtext = (EditText) dialog.findViewById(R.id.emailtext);
        final EditText pantext = (EditText) dialog.findViewById(R.id.pantext);
        final EditText tintext = (EditText) dialog.findViewById(R.id.tintext);
        final EditText ziptext = (EditText) dialog.findViewById(R.id.ziptext);
        final EditText gsttext = (EditText) dialog.findViewById(R.id.gsttext);
        final EditText addresstext = (EditText) dialog.findViewById(R.id.addresstext);

        //Fill Default Client Detail
        FillDefaultCustomer(DefaultClientUrl, spinner, StateSpinner, CitySpinner, emailtext,
                pantext, tintext, ziptext, gsttext, addresstext);

        //Get Country Spinner
        loadCountrySpinnerData(URL, spinner, CountryName);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adap, View view2, int ik, long ls) {

                String country = spinner.getItemAtPosition(spinner.getSelectedItemPosition()).toString();
                loadStateSpinnerData(StateURL, StateSpinner, StateName, country);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // DO Nothing here
            }
        });

        //Get State Spinner
        StateSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adap, View view2, int ik, long ls) {
                String state = StateSpinner.getItemAtPosition(StateSpinner.getSelectedItemPosition()).toString();
                loadCitySpinnerData(CityUrl, CitySpinner, CityName, state);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // DO Nothing here
            }
        });

        //Get City Spinner
        CitySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adap, View view2, int ik, long ls) {
                String city = CitySpinner.getItemAtPosition(CitySpinner.getSelectedItemPosition()).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // DO Nothing here
            }
        });


        DisplayMetrics displayMetrics = z.getResources().getDisplayMetrics();
        int dialogWidth = (int) (displayMetrics.widthPixels * 0.50);
        int dialogHeight = (int) (displayMetrics.heightPixels * 0.90);
        dialog.getWindow().setLayout(dialogWidth, dialogHeight);
        dialog.hide();

        //Add Customer
        addcustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addcustomer(MainActivity.this, dialog);
            }
        });

        //Search Customer
        searchcustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                searchcustomer(MainActivity.this);
            }
        });

        //for Cart Product
        mList3 = findViewById(R.id.cartrecycler);
        movieList3 = new ArrayList<>();
        adapter3 = new CartAdapter(getApplicationContext(), movieList3);
        linearLayoutManager3 = new LinearLayoutManager(this);
        linearLayoutManager3.setOrientation(LinearLayoutManager.VERTICAL);
        mList3.setHasFixedSize(true);
        mList3.setAdapter(adapter3);
        linearLayoutManager3 = new GridLayoutManager(this, 1);
        mList3.setLayoutManager(linearLayoutManager3);

        //for products
        mList2 = findViewById(R.id.categoryrecycler);
        movieList2 = new ArrayList<>();
        adaptera2 = new ProductAdapter(getApplicationContext(), movieList2);
        linearLayoutManager2 = new LinearLayoutManager(this);
        linearLayoutManager2.setOrientation(LinearLayoutManager.VERTICAL);
        mList2.setHasFixedSize(true);
        mList2.setAdapter(adaptera2);
        linearLayoutManager2 = new GridLayoutManager(this, 4);
        mList2.setLayoutManager(linearLayoutManager2);

        getproductData("0");
        getcartData(s);

        //for down category
        mList = findViewById(R.id.main_list);
        movieList = new ArrayList<>();
        adaptera = new CategoryAdapter(getApplicationContext(), movieList);
        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mList.setHasFixedSize(true);
        mList.setLayoutManager(linearLayoutManager);
        mList.setAdapter(adaptera);

        getData();


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        //Get Serach Default Customer
        txtnumber.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            Context s = getApplicationContext();

            @Override
            public void onFocusChange(View v, boolean hasFocus)
            {
                //Fill Default Client Detail
                    String q = txtnumber.getText().toString();
                    GetSearchClientClear obj = new GetSearchClientClear();
                    obj.SearchCustomer(txtname, s, spinner, StateSpinner, CitySpinner, emailtext,
                     pantext, tintext, ziptext, gsttext, addresstext, q);
                    //  Toast.makeText(s, "" + q, Toast.LENGTH_SHORT).show();
            }
        });
    }

    //Get Category
    private void getData() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject jsonObject = response.getJSONObject(i);

                        Category_List category = new Category_List();
                        category.setTitle(jsonObject.getString("CategoryName"));
                        category.setId(jsonObject.getString("Id"));
                        movieList.add(category);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        progressDialog.dismiss();
                    }
                }
                adaptera.notifyDataSetChanged();
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
                progressDialog.dismiss();
            }
        });
        RequestQueue requestQueuec = Volley.newRequestQueue(this);
        requestQueuec.add(jsonArrayRequest);
    }

    //Get Product Data
    public void getproductData(String category_id) {
        mList2.removeAllViewsInLayout();
        String c = "";
        if (category_id != "")
        {

            c = url2 + "?CategoryId=" + category_id;
        }

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait..");
        progressDialog.show();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(c.trim(), new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                progressDialog.hide();
                String str = response.toString();
                if (str != "NoRecord") {
                    movieList2.clear();
                    adaptera.notifyDataSetChanged();

                    for (int i = 0; i < response.length(); i++) {
                        Product_List product = new Product_List();
                        JSONObject jsonObject = null;
                        try {
                            jsonObject = response.getJSONObject(i);
                            product.setTitle(jsonObject.getString("Name"));
                            product.setPrice(jsonObject.getString("Price"));
                            product.setPath(jsonObject.getString("Image"));
                            product.setId(jsonObject.getString("ProductId"));

                            movieList2.add(product);

                        } catch (JSONException e)
                        {
                            e.printStackTrace();
                            progressDialog.dismiss();
                        }
                    }

                    progressDialog.dismiss();
                } else {
                    movieList2.clear();
                    adaptera.notifyDataSetChanged();
                    Toast.makeText(MainActivity.this, "No Product Found!", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
                progressDialog.dismiss();
            }
        });
        RequestQueue requestQueuec = Volley.newRequestQueue(this);
        requestQueuec.add(jsonArrayRequest);
    }

    //Get Cart Data
    public void getcartData(final String product_id) {
        mList2.removeAllViewsInLayout();

        String carturl="http://192.168.1.50/Mpostest/GstBilling.asmx/GetProductDetail";
        String c=carturl+"?ProductId="+product_id;
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait..");
        progressDialog.show();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(c.trim(), new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                progressDialog.hide();
                String str = response.toString();
                if (str != "NoRecord") {
                    adapter3.notifyDataSetChanged();

                    for (int i = 0; i < response.length(); i++) {
                        CartList cart = new CartList();
                        JSONObject jsonObject = null;
                        try {

                            jsonObject = response.getJSONObject(i);
                            cart.setProductName(jsonObject.getString("Name"));
                            cart.setProductPrice(jsonObject.getString("Price"));
                            cart.setShortDesc(jsonObject.getString("Description"));
                            cart.setProductId(jsonObject.getString("ProductId"));
                            movieList3.add(cart);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            progressDialog.dismiss();
                        }
                    }

                    progressDialog.dismiss();
                } else {
                    adapter3.notifyDataSetChanged();
                    Toast.makeText(MainActivity.this, "No Product Found!", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
                progressDialog.dismiss();
            }
        });
        RequestQueue requestQueuec = Volley.newRequestQueue(this);
        requestQueuec.add(jsonArrayRequest);
    }



    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //for Main Activity Instance
    public static MainActivity getInstance() {
        return instance;
    }

    //for Add Customer Pop-Up
    private void addcustomer(final Context context, final Dialog dialog) {

        final String s = "Hello Java";
        ImageButton btncancel = (ImageButton) dialog.findViewById(R.id.btncancel);
        Button btnsubmit = (Button) dialog.findViewById(R.id.btnsubmit);


        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                msg(s);
            }
        });


        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        int dialogWidth = (int) (displayMetrics.widthPixels * 0.50);
        int dialogHeight = (int) (displayMetrics.heightPixels * 0.90);
        dialog.getWindow().setLayout(dialogWidth, dialogHeight);
        dialog.show();

    }

    //for Fill Default Customer Value
    private void FillDefaultCustomer(String DefaultClientUrl, final Spinner spinner, final Spinner stateSpinner,
                                     final Spinner citySpinner, final EditText emailtext, final EditText pantext, final EditText tintext, final EditText ziptext,
                                     final EditText gsttext, final EditText addresstext) {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, DefaultClientUrl,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            JSONArray jsonArray = jsonObject.getJSONArray("DefaultClient");
                            String email = null;
                            String pan = null;
                            String gst = null;
                            String tin = null;
                            String zip = null;
                            String country = null;
                            String state = null;
                            String city = null;
                            String address = null;

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                email = jsonObject1.getString("EmailId");
                                DefaultClientData.add(email);
                                gst = jsonObject1.getString("GSTNo");
                                DefaultClientData.add(gst);
                                tin = jsonObject1.getString("ContactNo");
                                DefaultClientData.add(tin);
                                zip = jsonObject1.getString("PinCode");
                                DefaultClientData.add(zip);
                                address = jsonObject1.getString("Address");
                                DefaultClientData.add(address);
                                pan = jsonObject1.getString("PanNo");
                                DefaultClientData.add(pan);
                                country = jsonObject1.getString("CountryName");
                                DefaultClientData.add(pan);
                                state = jsonObject1.getString("StateName");
                                DefaultClientData.add(pan);
                                city = jsonObject1.getString("CityName");
                                DefaultClientData.add(pan);
                            }
                            emailtext.setText(email);
                            gsttext.setText(gst);
                            tintext.setText(tin);
                            ziptext.setText(zip);
                            pantext.setText(pan);
                            addresstext.setText(address);

                            spinner.setSelection(getIndex(spinner, country));
                            /*Toast.makeText(MainActivity.this, "Country = " + getIndex(spinner, country), Toast.LENGTH_SHORT).show();
                            stateSpinner.setSelection(getIndex(stateSpinner, state));
                            Toast.makeText(MainActivity.this, "State = " + getIndex(stateSpinner, state), Toast.LENGTH_SHORT).show();
                            citySpinner.setSelection(getIndex(citySpinner, city));
                            Toast.makeText(MainActivity.this, "City =" + getIndex(citySpinner, city), Toast.LENGTH_SHORT).show();
                       */ } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        int socketTimeout = 3000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(policy);
        requestQueue.add(stringRequest);

    }

    private int getIndex(Spinner spinner, String myString) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(myString)) {
                return i;
            }
        }

        return 0;
    }

    //for Search Customer Pop-Up
    private void searchcustomer(final Context context)
    {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.search_customer);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(true);
        Context x=getApplicationContext();
        

        final ArrayList<String> ClientData = new ArrayList<>();
        AutoCompleteTextView searchbox = (AutoCompleteTextView) dialog.findViewById(R.id.searchbox);
        ImageButton btnsearchcancel = (ImageButton) dialog.findViewById(R.id.btnsearchcancel);
        final TextView name = (TextView) dialog.findViewById(R.id.name);
        final TextView address = (TextView) dialog.findViewById(R.id.address);
        final TextView cnumber = (TextView) dialog.findViewById(R.id.cnumber);
        final TextView pnumber = (TextView) dialog.findViewById(R.id.pnumber);
        final TextView email = (TextView) dialog.findViewById(R.id.email);
        final TextView gnumber = (TextView) dialog.findViewById(R.id.gnumber);
        ImageButton btndetail = (ImageButton) dialog.findViewById(R.id.btndetail);
        Button addbtn = (Button) dialog.findViewById(R.id.addbtn);
        ArrayList<String> getnumberlist = new ArrayList<String>();

        String getnumurl="http://192.168.1.50/Mpostest/GstBilling.asmx/GetAllClient";
        String getsearchclient="http://192.168.1.50/Mpostest/GstBilling.asmx/SearchClient";
        BindNumberACT obj2=new BindNumberACT();
        obj2.BindCustomerNumber(getnumberlist,searchbox,x,getnumurl);

        searchbox.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {

            }
        });

        btnsearchcancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
            }
        });

        addbtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(context, "Customer is Active Now", Toast.LENGTH_SHORT).show();
            }
        });

        btndetail.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String enternumber=searchbox.getText().toString();
                SearchClient obj=new SearchClient();
                obj.GetSearchCustomer(x,getsearchclient,name,address,cnumber,pnumber,email,gnumber,ClientData,enternumber);
            }
        });
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        int dialogWidth = (int) (displayMetrics.widthPixels * 0.50);
        int dialogHeight = (int) (displayMetrics.heightPixels * 0.90);
        dialog.getWindow().setLayout(dialogWidth, dialogHeight);
        dialog.show();


    }


    //for country Spinner
    private void loadCountrySpinnerData(String url, final android.widget.Spinner spinner, final ArrayList<String> CountryName) {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray jsonArray = jsonObject.getJSONArray("Country");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        String country = jsonObject1.getString("CountryName");
                        CountryName.add(country);

                    }
                    spinner.setAdapter(new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, CountryName));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        int socketTimeout = 3000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(policy);
        requestQueue.add(stringRequest);
    }

    //for State Spinner
    private void loadStateSpinnerData(String StateURL, final Spinner spinner, final ArrayList<String> StateName, final String country) {
        String Urlc = StateURL + "?CountryName=" + country;
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Urlc, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                StateName.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray jsonArray = jsonObject.getJSONArray("State");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        String country = jsonObject1.getString("StateName");
                        StateName.add(country);

                    }
                    spinner.setAdapter(new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, StateName));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        int socketTimeout = 3000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(policy);
        requestQueue.add(stringRequest);
    }

    //for City Spinner
    private void loadCitySpinnerData(String cityURL, final Spinner CitySpinner, final ArrayList<String> CityName, final String state) {
        String Urlc = cityURL + "?StateName=" + state;
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Urlc, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                CityName.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray jsonArray = jsonObject.getJSONArray("City");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        String country = jsonObject1.getString("CityName");
                        CityName.add(country);
                    }
                    CitySpinner.setAdapter(new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, CityName));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        int socketTimeout = 3000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(policy);
        requestQueue.add(stringRequest);
    }

    public void msg(String k)
    {
        Toast.makeText(this, "Customer Added Successfully", Toast.LENGTH_SHORT).show();
    }

}

