package com.example.rahul.mpos;

public class DefaultClientList
{
    public String name;
    public String number;

    public String getName() 
    {
        return name;
    }

    public String getNumber()
    {
        return number;
    }

    public void setName(String name) 
    {
        this.name = name;
    }

    public void setNumber(String number)
    {
        this.number = number;
    }

    public DefaultClientList()
    {

    }
    
}
