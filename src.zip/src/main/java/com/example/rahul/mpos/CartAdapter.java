package com.example.rahul.mpos;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {
    private Context context;
    private List<CartList> list;


    public CartAdapter(Context context, List<CartList> list) {
        this.context = context;
        this.list =list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.cart_layout, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        CartList CList = list.get(position);
        holder.ProductName.setText(CList.getProductName());
        holder.ProductPrice.setText(CList.getProductPrice());
        holder.ProductShortDesc.setText(CList.getProductShortDesc());
        holder.ProductQty.setText(CList.getProductQty());
        holder.id.setText(CList.getProductId());
    }

    @Override
    public int getItemCount()
    {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        public TextView ProductName;
        public TextView ProductPrice;
        public TextView ProductShortDesc;
        public TextView ProductQty;
        public TextView id;

        public ViewHolder(View itemView)
        {
            super(itemView);

            ProductName = itemView.findViewById(R.id.ProductName);
            ProductPrice=itemView.findViewById(R.id.ProductPrice);
            ProductShortDesc=itemView.findViewById(R.id.ProductShortDesc);
            ProductQty=itemView.findViewById(R.id.ProductQty);
            id=itemView.findViewById(R.id.id);
        }

    }
}
