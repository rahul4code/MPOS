package com.example.rahul.mpos;

public class Product_List  {

    public String title;
    public String price;
    public String path;
    public String id;


    public String getPath()
    {
        return path;
    }

    public void setPath(String path)
    {
        this.path = path;
    }

    public Product_List()
    {

    }

    public String getPrice()
    {
        return price;
    }

    public void setPrice(String price)
    {
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public Product_List(String title, String price , String path,String id)
    {
        this.title = title;
        this.price=price;
        this.path=path;
        this.id=id;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

}
