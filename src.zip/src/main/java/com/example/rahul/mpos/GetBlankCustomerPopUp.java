package com.example.rahul.mpos;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.widget.EditText;

import java.util.ArrayList;

public class GetBlankCustomerPopUp
{
    public void GetBlankAddCustomer(Context x, EditText txtnumber)
    {
        final Dialog dialog = new Dialog(x);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.add_customer);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(true);

        ArrayList<String> CountryName = new ArrayList<String>();
        final ArrayList<String> StateName = new ArrayList<String>();
        final ArrayList<String> CityName = new ArrayList<String>();

    }
}
