package com.example.rahul.mpos;

import android.content.Context;
import android.text.Editable;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class GetSearchClientClear
{
    String DefaultClientUrl="http://192.168.1.50/Mpostest/GstBilling.asmx/SearchClient";
    Context a;
    ArrayList DefaultClientData=new ArrayList();



        public void SearchCustomer(final EditText txtname, final Context x, final Spinner spinner, final Spinner stateSpinner,
        final Spinner citySpinner, final EditText emailtext, final EditText pantext, final EditText tintext, final EditText ziptext,
        final EditText gsttext, final EditText addresstext,final String q)
        {

            String urlk=DefaultClientUrl+"?clientMobileNo="+q;
            RequestQueue requestQueue = Volley.newRequestQueue(x);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, urlk,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response)
                        {
                            try {
                                String email = null;
                                String pan=null;
                                String gst = null;
                                String tin = null;
                                String zip = null;
                                String country = null;
                                String state = null;
                                String city = null;
                                String address=null;

                                if(response=="NoRecord")
                                {
                                    emailtext.setText("");
                                    pantext.setText("");
                                    tintext.setText("");
                                    ziptext.setText("");
                                    gsttext.setText("");
                                    addresstext.setText("");
                                    txtname.setText("New Customer");
                                }
                                else
                                {
                                    JSONObject jsonObject = new JSONObject(response);
                                    JSONArray jsonArray = jsonObject.getJSONArray("SearchClient");
                                    for (int i = 0; i < jsonArray.length(); i++)
                                    {
                                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                        email = jsonObject1.getString("EmailId");
                                        DefaultClientData.add(email);
                                        gst = jsonObject1.getString("GSTNo");
                                        DefaultClientData.add(gst);
                                        tin = jsonObject1.getString("ContactNo");
                                        DefaultClientData.add(tin);
                                        zip = jsonObject1.getString("PinCode");
                                        DefaultClientData.add(zip);
                                        address = jsonObject1.getString("Address");
                                        DefaultClientData.add(address);
                                        pan = jsonObject1.getString("PanNo");
                                        DefaultClientData.add(pan);
                                        country = jsonObject1.getString("CountryName");
                                        DefaultClientData.add(pan);
                                        state = jsonObject1.getString("StateName");
                                        DefaultClientData.add(pan);
                                        city = jsonObject1.getString("CityName");
                                        DefaultClientData.add(pan);
                                    }
                                    emailtext.setText("rahul");
                                    gsttext.setText(gst);
                                    tintext.setText(tin);
                                    ziptext.setText(zip);
                                    pantext.setText(pan);
                                    addresstext.setText(address);

                                }


                            } catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    error.printStackTrace();
                }
            });

            int socketTimeout = 30000;
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            stringRequest.setRetryPolicy(policy);
            requestQueue.add(stringRequest);
        }
}
