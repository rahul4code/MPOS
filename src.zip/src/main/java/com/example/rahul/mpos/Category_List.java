package com.example.rahul.mpos;

public class Category_List {
    public String title;
    public String id;

    public Category_List()
    {

    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public Category_List(String title, String id )
    {
        this.title = title;
        this.id=id;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

}
