package com.example.rahul.mpos;

public class CartList
{
    public String ProductName;
    public String ProductShortDesc;
    public String ProductPrice;
    public String ProductQty;
    public String ProductId;

    public void setProductId(String productId)
    {
        ProductId = productId;
    }

    public String getProductId()
    {
        return ProductId;
    }

    public CartList()
    {

    }

    public String getProductName() {
        return ProductName;
    }

    public String getProductShortDesc() {
        return ProductShortDesc;
    }

    public String getProductPrice() {
        return ProductPrice;
    }

    public String getProductQty() {
        return ProductQty;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }

    public void setShortDesc(String shortDesc) {
        ProductShortDesc = shortDesc;
    }

    public void setProductPrice(String productPrice) {
        ProductPrice = productPrice;
    }

    public void setProductQty(String productQty) {
        ProductQty = productQty;
    }




}
