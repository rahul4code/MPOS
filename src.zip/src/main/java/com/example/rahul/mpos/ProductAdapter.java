package com.example.rahul.mpos;

import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder>
{
   private Context context;
   private List<Product_List> list;

    public ProductAdapter(Context context, List<Product_List> list)
    {
        this.context = context;
        this.list=list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v = LayoutInflater.from(context).inflate(R.layout.album_layout, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ProductAdapter.ViewHolder holder, int  position)
    {
       Product_List movie = list.get(position);
        holder.productname.setText(movie.getTitle());
        holder.productprice.setText(movie.getPrice());
        holder.productid.setText(movie.getId());


        Glide.with(context)
                .load(movie.getPath())
                    .into(holder.image_view);

    }

    @Override
    public int getItemCount()
    {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        public TextView productname;
        public TextView productprice;
        ImageView image_view;
        public TextView productid;
        public LinearLayout product;
        public TextView categoryid;

        public ViewHolder(View itemView)
        {
            super(itemView);

            productname = itemView.findViewById(R.id.productname);
            productprice=itemView.findViewById(R.id.productprice);
            image_view=itemView.findViewById(R.id.image_view);
            productid=itemView.findViewById(R.id.productid);
            product=itemView.findViewById(R.id.product);

            product.setOnClickListener(this);

        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public void onClick(View v)
        {
            int count=0;
            String s = (String) productid.getText();
            if(MainActivity.getInstance().movieList3.stream().anyMatch(CartList->("productid").contains(s)))
            {
                count++;
            }
            MainActivity.getInstance().getcartData(s);
            MainActivity.getInstance().getproductData("0");
            Toast.makeText(context, ""+count, Toast.LENGTH_SHORT).show();
        }
    }
}
